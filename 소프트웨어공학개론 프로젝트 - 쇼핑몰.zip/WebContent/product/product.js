/*product 뷰 모듈에서 사용할 스크립트 함수들*/
function go_cart() {
  if (document.formm.quantity.value == "") {
    alert("수량을 입력하여 주세요.");
    document.formm.quantity.focus();
  } else {
    document.formm.action = "NonageServlet?command=cart_insert";
    document.formm.submit();
  }
}// 카트에 상품을 수량과 함께 담는다.

function go_cart_delete() {
  var count = 0;
  for ( var i = 0; i < document.formm.cseq.length; i++) {
    if (document.formm.cseq[i].checked == true) {
      count++;
    }
  }
  if (count == 0) {
    alert("삭제할 항목을 선택해 주세요.");

  } else {
    document.formm.action = "NonageServlet?command=cart_delete";
    document.formm.submit();
  }
}// 카트의 상품을 삭제한다.

function go_order_insert() {
  document.formm.action = "NonageServlet?command=order_insert";
  document.formm.submit();
}// 주문을 추가한다.

function go_order_delete() {
  var count = 0;
  for ( var i = 0; i < document.formm.oseq.length; i++) {
    if (document.formm.oseq[i].checked == true) {
      count++;
    }
  }
  if (count == 0) {
    alert("삭제할 항목을 선택해 주세요.");

  } else {
    document.formm.action = "NonageServlet?command=order_delete";
    document.formm.submit();
  }
}// 주문내역을 삭제한다.

function go_order() {
	document.formm.action = "NonageServlet?command=mypage";
	document.formm.submit();
}// 바로주문 처리(구현X)