/*QnA 뷰 모듈에서 이용될 스크립트 함수*/
function null_check_submit(){
	  if (document.formm.subject.value == "") {
		    alert("제목을 입력해 주세요.");
		    document.formm.subject.focus();
		  } else if (document.formm.content.value==""){
			  alert("내용을 입력해 주세요.");
			  document.formm.content.focus();
		  }
	  formm.submit();
}
// QNA 게시글이 제목 혹은 내용없이 등록되는 것을 막는 함수.