package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException; // 데이터베이스를 다루기 위한 패키지

public class DBManager { 

	/* 데이터베이스를 다루기위한(연결/연결 해제) 데이터베이스 매니저 클래스*/

	private static String url = "jdbc:oracle:thin:@localhost:1521:XE"; // 데이터베이스 URL
	private static String uid = "joeunott"; // 유저 ID
	private static String pwd = "1234"; // 비밀번호

	public static Connection getConnection() {
		Connection conn = null; // 데이터베이스에 접속하기위한 커넥션 객체
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, uid, pwd); // 연결 메소드
		} catch (Exception e) {
			e.printStackTrace(); // 데이터베이스에 정상적으로 접속할수 없는 경우 에러 출력
		}
		return conn; // 연결이 성공하였을 경우 객체 반환
	}

	public static void close(Connection conn, PreparedStatement pstmt, // 데이터베이스 종료를 위한 close 메소드
			ResultSet rset) {
		if (rset != null) {
			try {
				rset.close();
			} catch (SQLException e) {
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}

	public static void close(Connection conn, PreparedStatement pstmt) {

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
}
