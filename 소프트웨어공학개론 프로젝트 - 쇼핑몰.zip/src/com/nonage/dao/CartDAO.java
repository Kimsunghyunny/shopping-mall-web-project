package com.nonage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import util.DBManager;

import com.nonage.dto.CartVO;

/*데이터베이스의 장바구니 항목에 액세스하고, 조작하는 기능을 하는 객체*/
public class CartDAO {

  private CartDAO() {
  }

  private static CartDAO instance = new CartDAO();

  public static CartDAO getInstance() {
    return instance;
  }

  public void insertCart(CartVO cartVO) {// 카트에 삽입을 하기위한 메소드
    String sql = "insert into cart(cseq,id, pseq, quantity)" +
    		" values(cart_seq.nextval,?, ?, ?)";// sql 쿼리 작성
    
    Connection conn = null;
    PreparedStatement pstmt = null;
    
    try {
      conn = DBManager.getConnection(); // 연결 시도
      pstmt = conn.prepareStatement(sql); // 쿼리 수행을 위한 prepareStatement 객체 생성
      pstmt.setString(1, cartVO.getId());
      pstmt.setInt(2, cartVO.getPseq());
      pstmt.setInt(3, cartVO.getQuantity()); // 이하 값 설정
      pstmt.executeUpdate(); // 쿼리 실행
    } catch (Exception e) {// 쿼리문에 오류가 있을경우 에러 출력
      e.printStackTrace();
    } finally {
      DBManager.close(conn, pstmt);
    }
  }

  public ArrayList<CartVO> listCart(String userId) {
    ArrayList<CartVO> cartList = new ArrayList<CartVO>();    
    String sql = "select * from cart_view where id=? order by cseq desc"; // 카트를 내림차순으로 정렬후 선택한 상품을 볼수 있도록 설렉트문 쿼리 작성
    
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null; // 결과값을 받아오기위한 ResultSet 클래스
    
    try {
      conn = DBManager.getConnection();
      pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, userId); // 값 설정
      rs = pstmt.executeQuery(); // 쿼리 실행
      while (rs.next()) {
        CartVO cartVO = new CartVO();
        cartVO.setCseq(rs.getInt(1));
        cartVO.setId(rs.getString(2));
        cartVO.setPseq(rs.getInt(3));
        cartVO.setMname(rs.getString(4));
        cartVO.setPname(rs.getString(5));
        cartVO.setQuantity(rs.getInt(6));
        cartVO.setIndate(rs.getTimestamp(7));
        cartVO.setPrice2(rs.getInt(8));
        cartList.add(cartVO);
      } // 카트에 선택한 상품 담기
    } catch (Exception e) {
      e.printStackTrace();
    }finally {
      DBManager.close(conn, pstmt, rs);
    }
    return cartList;
  }

  public void deleteCart(int cseq) { // 장바구니 삭제 메소드
    String sql = "delete cart where cseq=?"; // cart_sequence 넘버에 해당하는 장바구니 삭제 쿼리
    
    Connection conn = null;
    PreparedStatement pstmt = null;
    
    try {
      conn = DBManager.getConnection();
      pstmt = conn.prepareStatement(sql);
      pstmt.setInt(1, cseq);
      pstmt.executeUpdate();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      DBManager.close(conn, pstmt);
    }
  }
}
